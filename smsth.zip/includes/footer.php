<table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>
                            <td align="center" valign="middle"><img src="images/line.gif" alt="" width="950" height="1" /></td>
                          </tr>
                          <tr>
                            <td align="center">
							<table width="90%" border="0">
 
</table>

							</td>
                          </tr>
                      </table>