<?php
// Common Messages	
		$sucessmessage[1] = "Added Successfully";
		$sucessmessage[2] = "Updated Successfully";
		$sucessmessage[3] = "Deleted Successfully";
		$sucessmessage[4] = "Registered Successfully";
		$sucessmessage[5] = "Status changed Successfully";		
		$sucessmessage[6] = "Imported Successfully";
		$sucessmessage[7] = "Mail successfully sent to selected users";
		$sucessmessage[8] = "Thank you for Registering ";
		$sucessmessage[9] = "Thank you for your Request.Someone from our Support Team will get back to you within 12-24 hrs";
		$sucessmessage[10] = "We welcome your feedback.Our Support Team will get back to you within 12-24 hrs.";
		$sucessmessage[11] = "Thank You for your Request.The User Name and Password will be sent to your Email.";		
		$sucessmessage[12] = "You have Successfully changed your Login Details. Please check your Email.";
		$sucessmessage[13] = "Thank you for Registering with us.<br />Once your account is activated you will receive an Email from us.";
		$sucessmessage[14] = "Thank you for your Request.Someone from our Team will get back to you within 12-24 hrs";
		$sucessmessage[15] = "Invalid Login";
		$sucessmessage[16] = "Successfully Logged out";
		$sucessmessage[17] = "Database Exported Successfully";	
        $sucessmessage[18] = "Invalid User Name";	
		$sucessmessage[19] = "Thank You for submitting the enquiry form. Your details has been received. Our administrative office shall get in touch with you soon.";	
		$sucessmessage[20] = "Academic Year Created successfully Please Login.";
?>
