<?php
	define('FROMINDEX', true);
	header('location:../?pid=1&loginlabel=LOGIN_ADMIN&action=login');
?>